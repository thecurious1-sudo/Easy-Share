<?php
$servername = "id17513492_easyshare";
$username = "id17513492_vaibhav";
$password = "M[~vO4bu&=DNU#>]";

$uniqueId=$_POST['uniqueID'];
// Create connection
$conn = mysqli_connect("localhost",$username,$password,$servername);
//$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
  echo $conn->connect_error;
}
else
{
$sql = "SELECT * FROM links where UniqueID='".$uniqueId."'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
  // output data of each row
  while($row = mysqli_fetch_assoc($result)) {
    echo $row["text"];
  }
} else {
  echo "0 results";
}


$conn->close();
}



?>